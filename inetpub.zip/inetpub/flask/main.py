from flask import Flask, request, render_template, redirect
import json
import csv
import datetime as dt

app = Flask(__name__)

@app.before_request
def before_request_handler():
    username = request.environ.get('REMOTE_USER')
    if username.startswith('ITACADEMY') is False:
        return "401 Unauthorized: User domain incorrect.", 401
    else:
        if "Administrator" in username:
            return "401 Unauthorized: User domain account required (Administrator disallowed).", 401

@app.route("/", methods=["GET"])
def welcome():
    username = request.environ.get('REMOTE_USER')
    friendly_name = username.replace('ITACADEMY\\','').replace('.',' ').title()
    return render_template("index.html", username=friendly_name)

@app.route("/message_board", methods=["GET","POST"])
def message_board():
    if request.method == "GET":
        username = request.environ.get('REMOTE_USER')
        friendly_name = username.replace('ITACADEMY\\','').replace('.',' ').title()
        f = open('C:/inetpub/flask/users.json', 'r')
        users = json.load(f)
        f.close()
        if friendly_name in users['ban']:
            return "You are banned from the IT Academy Message Board.", 401
        f = open('C:/inetpub/flask/messages.json', 'r')
        messages = json.load(f)
        f.close()
        for i in range(len(messages['messages'])):
            messages['messages'][i]['id'] = i
        return render_template("message_board.html", username=friendly_name, messages=messages['messages'], admin_users=users['admin'])
    else:
        if not len(request.form['message']) <= 0:
            username = request.environ.get('REMOTE_USER')
            friendly_name = username.replace('ITACADEMY\\','').replace('.',' ').title()
            f = open('C:/inetpub/flask/users.json', 'r')
            users = json.load(f)
            f.close()
            if friendly_name in users['ban']:
                return "You are banned from the IT Academy Message Board.", 401
            f = open('C:/inetpub/flask/messages.json', 'r')
            messages = json.load(f)
            f.close()
            f = open('C:/inetpub/flask/blocked_terms.csv', 'r')
            blocked_terms = list(csv.reader(f))
            f.close()
            message_content = request.form['message']
            for term in blocked_terms:
                if str(term) in message_content.lower():
                    message_content.replace(str(term), "*"*len(str(term)))
            message_raw_time = dt.datetime.now()
            message_time = str(message_raw_time.strftime('%m/%d/%Y %I:%M%p')).lower()
            msg_data = {}
            msg_data['name'] = friendly_name
            msg_data['message'] = message_content
            msg_data['time'] = message_time
            messages['messages'].append(msg_data)
            with open('C:/inetpub/flask/messages.json', 'w') as f:
                json.dump(messages, f)
                f.close()
        return redirect("http://10.2.10.250/message_board", code=302)

@app.route("/message_board/admin/<op>/<id>", methods=["GET"])
def msg_board_admin(op, id):
    if op == "delete":
        username = request.environ.get('REMOTE_USER')
        friendly_name = username.replace('ITACADEMY\\','').replace('.',' ').title()
        f = open('C:/inetpub/flask/users.json', 'r')
        users = json.load(f)
        f.close()
        f = open('C:/inetpub/flask/messages.json', 'r')
        messages = json.load(f)
        f.close()
        if messages['messages'][int(id)]['name'] == friendly_name:
            messages['messages'].pop(int(id))
            with open('C:/inetpub/flask/messages.json', 'w') as f:
                json.dump(messages, f)
                f.close()
        else:
            if friendly_name in users['admin']:
                messages['messages'].pop(int(id))
                with open('C:/inetpub/flask/messages.json', 'w') as f:
                    json.dump(messages, f)
                    f.close()
    elif op == "ban":
        username = request.environ.get('REMOTE_USER')
        friendly_name = username.replace('ITACADEMY\\','').replace('.',' ').title()
        f = open('C:/inetpub/flask/users.json', 'r')
        users = json.load(f)
        f.close()
        f = open('C:/inetpub/flask/messages.json', 'r')
        messages = json.load(f)
        f.close()
        if friendly_name in users['admin']:
            banned_user = messages['messages'][int(id)]['name']
            if not banned_user in users['admin']:
                users['ban'].append(banned_user)
                with open('C:/inetpub/flask/users.json', 'w') as f:
                    json.dump(users, f)
                    f.close()
    return redirect("http://10.2.10.250/message_board", code=302)

if __name__=='__main__':
    app.run(debug=True)
